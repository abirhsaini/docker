*Note, that any section that doesn’t have content should be omitted*

# MongoDB Kubernetes Operator 1.x.y

## Kubernetes Operator

* Breaking Changes
  * Breaking Change 1
* Changes
  * Change 1
* Bug fixes (*CVE issues go first*)
  * Fixes an issue ...


## MongoDBCommunity Resource
* Breaking Changes
  * Breaking Change 1
* Changes
  * Change 1
* Bug fixes (*CVE issues go first*)
  * Fixes an issue ...

## MongoDB Agent ReadinessProbe
* Breaking Changes
  * Breaking Change 1
* Changes
  * Change 1
* Bug fixes (*CVE issues go first*)
  * Fixes an issue ...

## Known Issues
* Issue 1
* Issue 2

## Miscellaneous
* Item 1
* Item 2

## Updated Image Tags
* mongodb-kubernetes-operator:0.3.0
* mongodb-agent:10.19.0.6562-1
* mongodb-kubernetes-operator-version-upgrade-post-start-hook:1.0.2

*All the images can be found in:*

https://quay.io/mongodb

