package v1

// +k8s:deepcopy-gen=package
// +versionName=v1
