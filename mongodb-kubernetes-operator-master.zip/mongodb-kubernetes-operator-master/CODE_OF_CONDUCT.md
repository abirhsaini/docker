# Code of Conduct

This project has adopted the [MongoDB Code of Conduct](https://www.mongodb.com/community-code-of-conduct).
If you see any violations of the above or have any other concerns or questions please contact us
using the following email alias: community-conduct@mongodb.com.
